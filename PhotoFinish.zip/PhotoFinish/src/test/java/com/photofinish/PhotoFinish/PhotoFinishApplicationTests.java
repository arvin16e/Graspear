package com.photofinish.PhotoFinish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoFinishApplicationTests {

	@Test
	void contextLoads() {
	}

}
