package com.photofinish.PhotoFinish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoFinishApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotoFinishApplication.class, args);
	}

}
